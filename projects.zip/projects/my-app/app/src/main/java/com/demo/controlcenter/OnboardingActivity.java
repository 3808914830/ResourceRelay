package com.demo.controlcenter;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class OnboardingActivity extends Activity {

    private float density;

    private LinearLayout contentContainer;
    private LinearLayout dotIndicator;
    private TextView btnNext;

    private int currentPage = 0;

    private static final String COLOR_BG        = "#F2F2F7";
    private static final String COLOR_TEXT      = "#1C1C1E";
    private static final String COLOR_DESC      = "#666666";
    private static final String COLOR_AGREE_BG  = "#FFFFFF";
    private static final String COLOR_AGREE_TX  = "#888888";
    private static final String COLOR_BLUE      = "#007AFF";
    private static final String COLOR_DOT_OFF   = "#CCCCCC";
    private static final String COLOR_WHITE     = "#FFFFFF";

    private static final String COLOR_ICON_BG_0 = "#E3F0FF";
    private static final String COLOR_ICON_BG_1 = "#FFF3E0";
    private static final String COLOR_ICON_BG_2 = "#FFEBEE";
    private static final String COLOR_ICON_BG_3 = "#E8F8EC";

    private static final String SP_APP         = "app_config";
    private static final String K_FIRST_LAUNCH = "first_launch";

    private static class PageData {
        final String title;
        final String desc;
        final int    iconRes;
        final String iconBg;

        PageData(String title, String desc, int iconRes, String iconBg) {
            this.title   = title;
            this.desc    = desc;
            this.iconRes = iconRes;
            this.iconBg  = iconBg;
        }
    }

    private static final PageData[] PAGES = {
            new PageData(
                    "欢迎使用 驱动管理",
                    "这是一个本地驱动与内核模块管理工具，帮助你方便地刷入、启用、删除驱动。",
                    android.R.drawable.ic_menu_manage,
                    COLOR_ICON_BG_0),
            new PageData(
                    "什么是驱动",
                    "驱动（.ko 文件或 Magisk 模块）是让内核支持更多功能的关键组件，刷入后才能生效。",
                    android.R.drawable.ic_menu_info_details,
                    COLOR_ICON_BG_1),
            new PageData(
                    "使用前须知",
                    "本工具仅支持已 Root 的设备，刷入驱动存在一定风险，请确保你了解自己的设备内核版本。",
                    android.R.drawable.ic_dialog_alert,
                    COLOR_ICON_BG_2),
            new PageData(
                    "用户协议与免责声明",
                    "继续使用即表示您已知晓：刷入驱动可能导致设备无法开机，一切后果由用户自行承担。本工具不提供任何形式的担保。",
                    android.R.drawable.ic_menu_agenda,
                    COLOR_ICON_BG_3)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        buildUI();
        renderPage(0);
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor(COLOR_BG));
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        contentContainer = new LinearLayout(this);
        contentContainer.setOrientation(LinearLayout.VERTICAL);
        contentContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(contentContainer);

        LinearLayout bottomArea = new LinearLayout(this);
        bottomArea.setOrientation(LinearLayout.VERTICAL);
        bottomArea.setGravity(Gravity.CENTER);

        dotIndicator = new LinearLayout(this);
        dotIndicator.setOrientation(LinearLayout.HORIZONTAL);
        dotIndicator.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        dotParams.bottomMargin = dp(24);
        dotIndicator.setLayoutParams(dotParams);
        bottomArea.addView(dotIndicator);

        btnNext = new TextView(this);
        btnNext.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        btnNext.setText("下一步");
        btnNext.setTextSize(16);
        btnNext.setTextColor(Color.parseColor(COLOR_WHITE));
        btnNext.setTypeface(null, Typeface.BOLD);
        btnNext.setGravity(Gravity.CENTER);
        btnNext.setBackground(createRoundRect(COLOR_BLUE, dp(28)));
        btnNext.setOnClickListener(v -> goNextPage());
        setPressFeedback(btnNext);
        bottomArea.addView(btnNext);

        root.addView(bottomArea);
        setContentView(root);
    }

    private void renderPage(int index) {
        currentPage = index;
        contentContainer.removeAllViews();

        PageData page = PAGES[index];

        ImageView icon = new ImageView(this);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(96), dp(96));
        ip.topMargin = dp(60);
        ip.bottomMargin = dp(40);
        ip.gravity = Gravity.CENTER_HORIZONTAL;
        icon.setLayoutParams(ip);
        icon.setBackground(createRoundRect(page.iconBg, dp(28)));
        icon.setPadding(dp(24), dp(24), dp(24), dp(24));
        icon.setImageResource(page.iconRes);
        contentContainer.addView(icon);

        TextView title = new TextView(this);
        title.setText(page.title);
        title.setTextSize(24);
        title.setTextColor(Color.parseColor(COLOR_TEXT));
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.bottomMargin = dp(16);
        title.setLayoutParams(tp);
        contentContainer.addView(title);

        TextView desc = new TextView(this);
        desc.setText(page.desc);
        desc.setTextSize(15);
        desc.setTextColor(Color.parseColor(COLOR_DESC));
        desc.setGravity(Gravity.CENTER);
        desc.setLineSpacing(dp(6), 1f);
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        dp2.leftMargin  = dp(16);
        dp2.rightMargin = dp(16);
        desc.setLayoutParams(dp2);
        contentContainer.addView(desc);

        if (index == PAGES.length - 1) {
            addAgreementBlock();
        }

        updateDots();
        updateButtonText();
    }

    private void addAgreementBlock() {
        ScrollView agreementScroll = new ScrollView(this);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = dp(24);
        agreementScroll.setLayoutParams(sp);

        TextView agreementText = new TextView(this);
        agreementText.setText(getAgreementContent());
        agreementText.setTextSize(13);
        agreementText.setTextColor(Color.parseColor(COLOR_AGREE_TX));
        agreementText.setLineSpacing(dp(4), 1f);
        agreementText.setPadding(dp(16), dp(16), dp(16), dp(16));
        agreementText.setBackground(createRoundRect(COLOR_AGREE_BG, dp(12)));

        agreementScroll.addView(agreementText);
        contentContainer.addView(agreementScroll);
    }

    private void goNextPage() {
        if (currentPage < PAGES.length - 1) {
            renderPage(currentPage + 1);
            return;
        }

        saveFirstLaunchFlag();
        openMainActivity();
        finish();
    }

    private void openMainActivity() {
        try {
            Class<?> clazz = Class.forName("com.demo.controlcenter.MainActivity");
            startActivity(new Intent(OnboardingActivity.this, clazz));
        } catch (Exception e) {
            Toast.makeText(this,
                    "启动主界面失败: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void updateDots() {
        dotIndicator.removeAllViews();
        for (int i = 0; i < PAGES.length; i++) {
            View dot = new View(this);
            int size = (i == currentPage) ? dp(24) : dp(8);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(size, dp(8));
            p.setMarginStart(dp(4));
            p.setMarginEnd(dp(4));
            dot.setLayoutParams(p);

            String color = (i == currentPage) ? COLOR_BLUE : COLOR_DOT_OFF;
            dot.setBackground(createRoundRect(color, dp(4)));
            dotIndicator.addView(dot);
        }
    }

    private void updateButtonText() {
        btnNext.setText(currentPage == PAGES.length - 1
                ? "同意并进入"
                : "下一步");
    }

    private void saveFirstLaunchFlag() {
        SharedPreferences sp = getSharedPreferences(SP_APP, MODE_PRIVATE);
        sp.edit().putBoolean(K_FIRST_LAUNCH, false).apply();
    }

    private String getAgreementContent() {
        return new StringBuilder()
                .append("用户协议与免责声明\n\n")
                .append("1. 本工具仅用于本地驱动与内核模块的管理，不提供任何在线服务。\n\n")
                .append("2. 使用本工具需要您的设备已经 Root，未 Root 的设备无法使用核心功能。\n\n")
                .append("3. 刷入驱动模块存在一定风险，可能导致设备无法开机、系统崩溃等后果。\n\n")
                .append("4. 请在明确了解自己设备的型号、内核版本、CPU 架构后，再刷入对应驱动。\n\n")
                .append("5. 本工具不保证任何驱动模块的兼容性与稳定性，刷入操作由用户自行决定。\n\n")
                .append("6. 因使用本工具导致的一切后果（包括但不限于设备损坏、数据丢失）由用户自行承担。\n\n")
                .append("7. 继续使用即表示您已阅读并同意以上全部内容。")
                .toString();
    }

    private void setPressFeedback(View view) {
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.97f).scaleY(0.97f)
                            .setDuration(100).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f)
                            .setDuration(350)
                            .setInterpolator(new OvershootInterpolator(2.5f))
                            .start();
                    v.performClick();
                    break;
            }
            return true;
        });
    }

    private GradientDrawable createRoundRect(String colorHex, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(Color.parseColor(colorHex));
        d.setCornerRadius(radiusPx);
        return d;
    }

    private int dp(float dpValue) {
        return (int) (dpValue * density + 0.5f);
    }
}