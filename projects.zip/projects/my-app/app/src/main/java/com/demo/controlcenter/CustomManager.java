package com.demo.controlcenter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;

public class CustomManager {

    private static final String PREFS         = "custom_config";
    private static final String KEY_NAME      = "app_display_name";
    private static final String KEY_ICON_PATH = "app_icon_path";
    private static final String DEFAULT_NAME  = "驱动管理";
    private static final String CUSTOM_DIR    = "custom";

    private static final int ICON_MAX_DIM = 512;

    public static String getName(Context ctx) {
        if (ctx == null) return DEFAULT_NAME;
        try {
            String n = prefs(ctx).getString(KEY_NAME, DEFAULT_NAME);
            return (n == null || n.trim().isEmpty()) ? DEFAULT_NAME : n;
        } catch (Throwable t) {
            return DEFAULT_NAME;
        }
    }

    public static void setName(Context ctx, String name) {
        if (ctx == null || name == null) return;
        String v = name.trim();
        if (v.isEmpty()) return;
        try {
            prefs(ctx).edit().putString(KEY_NAME, v).apply();
        } catch (Throwable ignored) {}
    }

    public static String getIconPath(Context ctx) {
        if (ctx == null) return null;
        try {
            return prefs(ctx).getString(KEY_ICON_PATH, null);
        } catch (Throwable t) {
            return null;
        }
    }

    public static void setIconPath(Context ctx, String path) {
        if (ctx == null || path == null) return;
        try {
            prefs(ctx).edit().putString(KEY_ICON_PATH, path).apply();
        } catch (Throwable ignored) {}
    }

    public static Bitmap loadIcon(Context ctx) {
        String path = getIconPath(ctx);
        if (path == null) return null;

        File f = new File(path);
        if (!f.exists() || !f.isFile()) {
            try { prefs(ctx).edit().remove(KEY_ICON_PATH).apply(); }
            catch (Throwable ignored) {}
            return null;
        }

        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, opts);

            int w = opts.outWidth;
            int h = opts.outHeight;
            if (w <= 0 || h <= 0) return null;

            int maxDim = Math.max(w, h);
            int sampleSize = 1;
            while (maxDim / sampleSize > ICON_MAX_DIM * 2) {
                sampleSize *= 2;
            }

            opts = new BitmapFactory.Options();
            opts.inSampleSize = sampleSize;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;

            return BitmapFactory.decodeFile(path, opts);
        } catch (Throwable t) {
            return null;
        }
    }

    public static void reset(Context ctx) {
        if (ctx == null) return;

        try {
            prefs(ctx).edit().clear().apply();
        } catch (Throwable ignored) {}

        try {
            File dir = new File(ctx.getFilesDir(), CUSTOM_DIR);
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    deleteRecursively(f);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        try {
            if (f.isDirectory()) {
                File[] children = f.listFiles();
                if (children != null) {
                    for (File c : children) deleteRecursively(c);
                }
            }
            f.delete();
        } catch (Throwable ignored) {}
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}