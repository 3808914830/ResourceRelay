package com.demo.controlcenter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class FlashActivity extends Activity {

    private static final int REQ_PICK_FILE = 3001;

    private static final int  SILENT_ABORT_MS     = 30_000;
    private static final int  BACKUP_TIMEOUT_SEC  = 60;
    private static final int  DELETE_TIMEOUT_SEC  = 15;
    private static final int  SELINUX_TIMEOUT_SEC = 30;
    private static final int  VERIFY_TIMEOUT_SEC  = 10;
    private static final int  COPY_BUF_SIZE       = 8192;
    private static final int  MAX_LOG_LINES       = 500;
    private static final int  MAX_PENDING_LOGS    = 100;
    private static final int  WATCHDOG_TICK_MS    = 1000;
    private static final long MAX_FILE_SIZE       = 200L * 1024 * 1024;
    private static final long WAIT_EXIT_MS        = 5000L;

    private static final long KO_MIN_SIZE    = 1024L;
    private static final long KO_MAX_SIZE    = 50L * 1024 * 1024;
    private static final long ZIP_TOTAL_MAX  = 500L * 1024 * 1024;
    private static final long ENTRY_MAX_SIZE = 50L * 1024 * 1024;

    private static final int MAX_SH_SCAN_LINES = 5000;
    private static final int MAX_SH_SCAN_BYTES = 256 * 1024;
    private static final int ZIP_MAX_ENTRIES   = 5000;

    private static final int C_BG     = 0xFFF2F2F7;
    private static final int C_CARD   = 0xFFFFFFFF;
    private static final int C_TEXT   = 0xFF1C1C1E;
    private static final int C_SUB    = 0xFF8E8E93;
    private static final int C_BLUE   = 0xFF007AFF;
    private static final int C_GREEN  = 0xFF34C759;
    private static final int C_RED    = 0xFFFF3B30;
    private static final int C_ORANGE = 0xFFFF9500;
    private static final int C_GRAY   = 0xFFE5E5EA;
    private static final int C_WHITE  = 0xFFFFFFFF;

    private static final int CARD_STROKE_COLOR = 0x0F000000;

    private static final String SP_NAME          = "flash_prefs";
    private static final String SP_KEY_LAST_ID   = "last_module_id";
    private static final String SP_KEY_LAST_PATH = "last_selected_path";

    private static final Object LOG_TOKEN = new Object();

    private static final Pattern MODULE_ID_SAFE_STRICT =
            Pattern.compile("^(?!\\.$)(?!\\.\\.$)[A-Za-z0-9._-]+$");

    private static final Pattern[] DANGER_PATTERNS = {
            Pattern.compile("\\brm\\s+-rf\\s+/\\s*[;#$]"),
            Pattern.compile("\\brm\\s+-rf\\s+/\\s*\\*"),
            Pattern.compile("\\brm\\s+-rf\\s+--no-preserve-root"),

            Pattern.compile(
                    "\\brm\\s+-rf?\\s+[\"']?/\\s*(system|vendor|data|boot|"
                    + "recovery|metadata|product|system_ext|odm|my_)\\b"
                    + "\\s*[\"']?\\s*[;#]?\\s*$"),
            Pattern.compile(
                    "\\brm\\s+-rf?\\s+[\"']?/\\s*(system|vendor|data|boot|"
                    + "recovery|metadata|product|system_ext|odm|my_)/"
                    + "\\s*[\"']?\\s*[;#]?\\s*$"),
            Pattern.compile(
                    "\\brm\\s+-rf?\\s+[\"']?/\\s*(system|vendor|data|boot|"
                    + "recovery|metadata|product|system_ext|odm)/\\*"),
            Pattern.compile(
                    "\\brm\\s+-rf?\\s+[\"']?/\\s*(system|vendor|data|boot|"
                    + "recovery|metadata|product|system_ext|odm)/\\.\\*"),
            Pattern.compile(
                    "\\brm\\s+-rf?\\s+[\"']?/\\s*(system|vendor|data|boot|"
                    + "recovery|metadata|product|system_ext|odm)\\b"
                    + "\\s*[\"']?\\s*[|&>]"),

            Pattern.compile("\\bdd\\s+if=.*of=/dev/block/"),
            Pattern.compile("\\bmkfs\\.(ext[234]|f2fs|vfat)\\b"),
            Pattern.compile("\\bformat\\s+/"),
    };

    private final Handler MAIN = new Handler(Looper.getMainLooper());

    private final AtomicLong runToken = new AtomicLong(0);
    private final AtomicInteger pendingLogCount = new AtomicInteger(0);
    private final AtomicInteger droppedLogCount = new AtomicInteger(0);

    private final Object flashLock = new Object();

    private static final ScheduledExecutorService WATCHDOG =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "flash-watchdog");
                t.setDaemon(true);
                return t;
            });

    private float density;

    private TextView     tvFileName;
    private TextView     tvStatus;
    private LinearLayout logContainer;
    private ScrollView   logScroll;

    private TextView btnCancel;
    private TextView btnStart;

    private String  selectedPath = null;
    private String  selectedName = null;
    private String  moduleId     = null;
    private boolean sessionInstalledZip = false;

    private boolean needForce     = false;
    private boolean isDriverFile  = false;
    private boolean isShScript    = false;

    private volatile boolean flashing       = false;
    private volatile boolean aborted        = false;
    private volatile boolean hasDriverOp    = false;
    private volatile boolean sawDoneMarker  = false;
    private volatile Process currentProcess = null;
    private volatile boolean copyCancelled  = false;

    private volatile long lastOutputTime = 0L;
    private volatile long flashStartTime = 0L;

    private boolean scrollPending = false;

    private ScheduledFuture<?> watchdogFuture = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;

        SharedPreferences sp = getSharedPreferences(SP_NAME, MODE_PRIVATE);
        sp.edit()
                .putString(SP_KEY_LAST_ID, null)
                .putString(SP_KEY_LAST_PATH, null)
                .apply();

        buildUI();
        pickFile();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        copyCancelled = true;
        flashing = false;
        stopWatchdog();
        killProcessNow();
        MAIN.removeCallbacksAndMessages(LOG_TOKEN);
    }

    private boolean canTouchUi() {
        return !isFinishing() && !isDestroyed();
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        root.addView(buildTitle());
        root.addView(buildFileCard());
        root.addView(buildLogCard());
        root.addView(buildButtonRow());

        setContentView(root);
    }

    private TextView buildTitle() {
        TextView title = new TextView(this);
        title.setText("刷入驱动");
        title.setTextSize(22);
        title.setTextColor(C_TEXT);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.bottomMargin = dp(16);
        title.setLayoutParams(tp);
        return title;
    }

    private LinearLayout buildFileCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(18), dp(20), dp(18));
        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        applyCardStyle(card);

        TextView label = new TextView(this);
        label.setText("已选文件");
        label.setTextSize(12);
        label.setTextColor(C_SUB);
        card.addView(label);

        tvFileName = new TextView(this);
        tvFileName.setText("等待选择...");
        tvFileName.setTextSize(16);
        tvFileName.setTextColor(C_TEXT);
        tvFileName.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams fnp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        fnp.topMargin = dp(6);
        tvFileName.setLayoutParams(fnp);
        card.addView(tvFileName);

        tvStatus = new TextView(this);
        tvStatus.setText("等待选择文件");
        tvStatus.setTextSize(13);
        tvStatus.setTextColor(C_SUB);
        LinearLayout.LayoutParams tsp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tsp.topMargin = dp(12);
        tvStatus.setLayoutParams(tsp);
        card.addView(tvStatus);

        return card;
    }

    private LinearLayout buildLogCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        LinearLayout.LayoutParams lcp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lcp.topMargin = dp(12);
        card.setLayoutParams(lcp);
        applyCardStyle(card);

        TextView title = new TextView(this);
        title.setText("执行日志");
        title.setTextSize(12);
        title.setTextColor(C_SUB);
        card.addView(title);

        logScroll = new ScrollView(this);
        LinearLayout.LayoutParams lsp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lsp.topMargin = dp(8);
        logScroll.setLayoutParams(lsp);

        logContainer = new LinearLayout(this);
        logContainer.setOrientation(LinearLayout.VERTICAL);
        logScroll.addView(logContainer);
        card.addView(logScroll);

        return card;
    }

    private LinearLayout buildButtonRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(16);
        row.setLayoutParams(bp);

        btnCancel = buildButton("取消", C_GRAY, C_TEXT);
        btnCancel.setOnClickListener(v -> {
            vibrate();
            if (flashing) {
                aborted = true;
                appendLog("⚠️ 用户取消刷入，正在中止...", C_ORANGE);
                killProcessNow();
                endFlash();
            } else {
                finish();
            }
        });
        row.addView(btnCancel);

        btnStart = buildButton("开始刷入", C_BLUE, C_WHITE);
        btnStart.setOnClickListener(v -> onStartClick());
        row.addView(btnStart);

        return row;
    }

    private void onStartClick() {
        vibrate();
        if (!isDriverFile) {
            Toast.makeText(this, "非驱动文件，无法刷入", Toast.LENGTH_SHORT).show();
            return;
        }

        synchronized (flashLock) {
            if (flashing) return;
            flashing = true;
        }

        btnStart.setEnabled(false);
        btnStart.setAlpha(0.5f);

        if (!RootManager.get().requireRoot(this)) {
            endFlash();
            return;
        }

        if (isShScript) {
            showShConfirmDialog();
            return;
        }

        if (needForce) {
            showForceConfirmDialog();
        } else {
            startFlash(false);
        }
    }

    private void showForceConfirmDialog() {
        final boolean[] handled = {false};
        AlertDialog d = new AlertDialog.Builder(FlashActivity.this)
                .setTitle("⚠️ 危险操作")
                .setMessage("驱动与当前环境不匹配，强制刷入极大概率导致手机无法开机（变砖）。\n\n确定继续吗？")
                .setPositiveButton("我已知晓，强制刷入", (dlg, w) -> {
                    handled[0] = true;
                    startFlash(true);
                })
                .setNegativeButton("取消", (dlg, w) -> {
                    handled[0] = true;
                    endFlash();
                })
                .setOnCancelListener(dlg -> {
                    handled[0] = true;
                    endFlash();
                })
                .setCancelable(false)
                .create();
        d.setOnDismissListener(dlg -> {
            if (!handled[0]) endFlash();
        });
        d.show();
    }

    private void showShConfirmDialog() {
        String kernel = KernelDetector.getKernelVersion();
        if (kernel == null || kernel.isEmpty()) kernel = "未知";

        final String fileName = selectedName == null ? "未命名.sh" : selectedName;
        final String msg =
                "即将刷入：\n" +
                "    " + fileName + "\n\n" +
                "请确认：\n" +
                "  · 文件内容与当前内核（" + kernel + "）一致\n" +
                "  · 文件来源可信、内容无恶意\n" +
                "  · 已了解刷入风险\n\n" +
                "刷入失败可能导致设备异常。\n是否继续？";

        final boolean[] handled = {false};

        AlertDialog d = new AlertDialog.Builder(FlashActivity.this)
                .setTitle("⚠️ 刷入前确认")
                .setMessage(msg)
                .setPositiveButton("已确认，开始刷入", (dlg, w) -> {
                    handled[0] = true;
                    startFlash(false);
                })
                .setNegativeButton("取消", (dlg, w) -> {
                    handled[0] = true;
                    endFlash();
                })
                .setOnCancelListener(dlg -> {
                    handled[0] = true;
                    endFlash();
                })
                .setCancelable(false)
                .create();
        d.setOnDismissListener(dlg -> {
            if (!handled[0]) endFlash();
        });
        d.show();
    }

    private TextView buildButton(String text, int bgColor, int textColor) {
        TextView btn = new TextView(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(54), 1f);
        p.setMarginStart(dp(6));
        p.setMarginEnd(dp(6));
        btn.setLayoutParams(p);
        btn.setText(text);
        btn.setTextSize(16);
        btn.setTextColor(textColor);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setGravity(Gravity.CENTER);
        btn.setBackground(createRoundRect(bgColor, dp(27)));
        setPressFeedback(btn);
        return btn;
    }

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(
                    Intent.createChooser(intent, "选择驱动文件 (.sh / .zip)"),
                    REQ_PICK_FILE);
        } catch (Exception e) {
            appendLog("没有可用的文件管理器", C_RED);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_FILE) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            appendLog("已取消选择", C_SUB);
            finish();
            return;
        }

        handlePickedUri(data.getData());
    }

    private void handlePickedUri(Uri uri) {
        String fileName = getFileName(uri);
        String lower = fileName.toLowerCase();

        if (!lower.endsWith(".sh") && !lower.endsWith(".zip")) {
            tvFileName.setText(fileName);
            tvFileName.setTextColor(C_RED);
            tvStatus.setText("❌ 只支持 .sh / .zip 格式");
            tvStatus.setTextColor(C_RED);
            isDriverFile = false;
            isShScript   = false;
            sessionInstalledZip = false;
            btnStart.setText("无法刷入");
            btnStart.setBackground(createRoundRect(C_GRAY, dp(27)));
            btnStart.setEnabled(false);
            btnStart.setAlpha(0.5f);
            return;
        }

        tvFileName.setText(fileName);
        tvFileName.setTextColor(C_TEXT);
        tvStatus.setText("正在复制文件...");
        tvStatus.setTextColor(C_SUB);
        appendLog("已选择: " + fileName, C_BLUE);

        copyCancelled = false;

        new Thread(() -> {
            String realPath = copyToPrivate(uri, fileName);

            if (realPath == null || realPath.startsWith("TOO_LARGE:")) {
                final boolean tooLarge = (realPath != null
                        && realPath.startsWith("TOO_LARGE:"));
                final String mbText = tooLarge
                        ? realPath.substring("TOO_LARGE:".length())
                        : null;

                MAIN.post(() -> {
                    if (!canTouchUi()) return;
                    if (tooLarge) {
                        if (mbText != null && mbText.startsWith(">")) {
                            appendLog("❌ 文件超过 "
                                    + (MAX_FILE_SIZE / 1024 / 1024)
                                    + "MB 上限，已中止", C_RED);
                        } else if (mbText != null && !mbText.isEmpty()) {
                            appendLog("❌ 文件过大 (" + mbText + "MB)，上限 "
                                    + (MAX_FILE_SIZE / 1024 / 1024) + "MB", C_RED);
                        } else {
                            appendLog("❌ 文件超过上限，已中止", C_RED);
                        }
                    } else {
                        appendLog("❌ 复制文件失败", C_RED);
                    }
                    finish();
                });
                return;
            }

            boolean isDriver = false;
            String  realId   = null;
            String  rejectReason = null;
            boolean shScript = lower.endsWith(".sh");

            if (lower.endsWith(".zip")) {
                ZipScanResult zr = scanZip(realPath);
                isDriver = zr.isDriver;
                realId   = zr.moduleId;
                rejectReason = zr.rejectReason;
            } else {
                isDriver = true;

                String danger = checkDangerLocalFile(realPath);
                if (danger != null) {
                    isDriver = false;
                    rejectReason = "脚本含危险命令: " + danger;
                }
            }

            final boolean fDriver = isDriver;
            final String  fId     = realId;
            final String  fReject = rejectReason;
            final boolean fSh     = shScript;

            MAIN.post(() -> {
                if (!canTouchUi()) return;
                selectedPath = realPath;
                selectedName = fileName;
                moduleId     = fId;
                isShScript   = fSh;

                SharedPreferences sp = getSharedPreferences(SP_NAME, MODE_PRIVATE);
                sp.edit()
                        .putString(SP_KEY_LAST_PATH, realPath)
                        .putString(SP_KEY_LAST_ID, fId)
                        .apply();

                onValidateFinished(fileName, fDriver, fReject);
            });
        }).start();
    }

    private static String sanitizeFileName(String name) {
        if (name == null || name.isEmpty()) return "unknown";
        StringBuilder sb = new StringBuilder(name.length());
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c == '/' || c == '\\' || c == '\0' || c == ':'
                    || c == '*' || c == '?' || c == '"'
                    || c == '<' || c == '>' || c == '|'
                    || c < 0x20
                    || (c >= 0x7F && c <= 0x9F)
                    || c == 0x200B || c == 0x200C || c == 0x200D
                    || c == 0x200E || c == 0x200F
                    || c == 0x202A || c == 0x202B || c == 0x202C
                    || c == 0x202D || c == 0x202E
                    || c == 0x2066 || c == 0x2067 || c == 0x2068 || c == 0x2069
                    || c == 0xFEFF) {
                sb.append('_');
            } else {
                sb.append(c);
            }
        }
        String s = sb.toString();
        if (s.length() > 100) {
            s = s.substring(0, 100);
            if (Character.isHighSurrogate(s.charAt(s.length() - 1))) {
                s = s.substring(0, s.length() - 1);
            }
        }
        if (s.isEmpty() || s.equals(".") || s.equals("..")) s = "unknown";
        return s;
    }

    private String copyToPrivate(Uri uri, String fileName) {
        long size = queryFileSize(uri);
        if (size > MAX_FILE_SIZE) {
            return "TOO_LARGE:" + (size / 1024 / 1024);
        }

        File dir = new File(getFilesDir(), "flash");
        if (!dir.exists() && !dir.mkdirs()) return null;

        String safeName = sanitizeFileName(fileName);
        File outFile = new File(dir, System.currentTimeMillis() + "_" + safeName);

        try {
            if (!outFile.getCanonicalPath().startsWith(dir.getCanonicalPath())) {
                return null;
            }
        } catch (Exception e) {
            return null;
        }

        try (InputStream is = getContentResolver().openInputStream(uri);
             FileOutputStream fos = new FileOutputStream(outFile)) {

            if (is == null) return null;

            byte[] buf = new byte[COPY_BUF_SIZE];
            int len;
            long total = 0;
            while ((len = is.read(buf)) > 0) {
                if (copyCancelled) {
                    try { fos.close(); } catch (Throwable ignored) {}
                    try { outFile.delete(); } catch (Throwable ignored) {}
                    return null;
                }

                total += len;
                if (total > MAX_FILE_SIZE) {
                    try { fos.close(); } catch (Throwable ignored) {}
                    try { outFile.delete(); } catch (Throwable ignored) {}
                    return "TOO_LARGE:>";
                }
                fos.write(buf, 0, len);
            }
            fos.flush();

            File[] olds = dir.listFiles();
            if (olds != null) {
                for (File f : olds) {
                    if (!f.equals(outFile)) {
                        try { f.delete(); } catch (Throwable ignored) {}
                    }
                }
            }

            return outFile.getAbsolutePath();
        } catch (Exception e) {
            try { outFile.delete(); } catch (Throwable ignored) {}
            return null;
        }
    }

    private long queryFileSize(Uri uri) {
        try (android.database.Cursor c = getContentResolver()
                .query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0) return c.getLong(idx);
            }
        } catch (Exception ignored) {}
        return -1;
    }

    private static boolean isDangerousLine(String line) {
        if (line == null || line.isEmpty()) return false;
        for (Pattern p : DANGER_PATTERNS) {
            if (p.matcher(line).find()) return true;
        }
        return false;
    }

    private String checkDangerLocalFile(String path) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(path),
                        StandardCharsets.UTF_8))) {
            String line;
            int n = 0;
            long bytes = 0;
            boolean truncated = false;
            while ((line = br.readLine()) != null) {
                bytes += line.length() + 1;
                if (bytes > MAX_SH_SCAN_BYTES) { truncated = true; break; }
                if (n++ >= MAX_SH_SCAN_LINES) { truncated = true; break; }

                String t = line.trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                if (isDangerousLine(t)) {
                    return t.substring(0, Math.min(50, t.length())) + "...";
                }
            }
            if (truncated) {
                appendLog("ℹ️ 脚本超长，仅扫描前 "
                        + (MAX_SH_SCAN_BYTES / 1024) + "KB / "
                        + MAX_SH_SCAN_LINES + " 行", C_SUB);
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private String checkDangerScript(ZipFile zf, ZipEntry e) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(zf.getInputStream(e),
                        StandardCharsets.UTF_8))) {
            String line;
            int n = 0;
            long bytes = 0;
            boolean truncated = false;
            while ((line = br.readLine()) != null) {
                bytes += line.length() + 1;
                if (bytes > MAX_SH_SCAN_BYTES) { truncated = true; break; }
                if (n++ >= MAX_SH_SCAN_LINES) { truncated = true; break; }

                String t = line.trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                if (isDangerousLine(t)) {
                    return t.substring(0, Math.min(50, t.length())) + "...";
                }
            }
            if (truncated) {
                appendLog("ℹ️ " + e.getName() + " 超长，仅扫描前 "
                        + (MAX_SH_SCAN_BYTES / 1024) + "KB / "
                        + MAX_SH_SCAN_LINES + " 行", C_SUB);
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static class ZipScanResult {
        boolean isDriver;
        String  moduleId;
        String  rejectReason;
    }

    private ZipScanResult scanZip(String path) {
        ZipScanResult r = new ZipScanResult();

        try (ZipFile zf = new ZipFile(path)) {
            boolean hasModuleProp = false;
            boolean hasRealKo     = false;
            String  moduleId      = null;
            long    totalSize     = 0L;
            int     entryCount    = 0;

            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                if (++entryCount > ZIP_MAX_ENTRIES) {
                    r.isDriver = false;
                    r.rejectReason = "zip 文件数量过多 (>"
                            + ZIP_MAX_ENTRIES + ")";
                    return r;
                }

                ZipEntry e = en.nextElement();
                if (e == null) continue;

                String name = e.getName();
                if (name == null || name.isEmpty()) continue;
                String lower = name.toLowerCase();

                if (name.contains("..")
                        || name.startsWith("/")
                        || name.indexOf('\0') >= 0
                        || name.indexOf('\\') >= 0) {
                    r.isDriver = false;
                    r.rejectReason = "包含非法路径: " + name;
                    return r;
                }

                if (isSymlinkEntry(e)) {
                    r.isDriver = false;
                    r.rejectReason = "包含 symlink: " + name;
                    return r;
                }

                long entrySize = e.getSize();
                if (entrySize > ENTRY_MAX_SIZE) {
                    r.isDriver = false;
                    r.rejectReason = "文件过大: " + name;
                    return r;
                }
                if (entrySize > 0) {
                    totalSize += entrySize;
                    if (totalSize > ZIP_TOTAL_MAX) {
                        r.isDriver = false;
                        r.rejectReason = "解压总体积过大（疑似 zip bomb）";
                        return r;
                    }
                }

                if (lower.equals("module.prop")
                        || lower.endsWith("/module.prop")) {
                    hasModuleProp = true;
                    if (!e.isDirectory() && moduleId == null) {
                        String id = readIdFromEntry(zf, e);
                        if (isSafeModuleId(id)) moduleId = id;
                    }
                }

                if (lower.endsWith(".ko") && !e.isDirectory()) {
                    if (isRealKoEntry(zf, e)) hasRealKo = true;
                }

                if ((lower.endsWith(".sh") || lower.endsWith(".rc"))
                        && !e.isDirectory()) {
                    String danger = checkDangerScript(zf, e);
                    if (danger != null) {
                        r.isDriver = false;
                        r.rejectReason = "脚本含危险命令: " + danger;
                        return r;
                    }
                }
            }

            if (!hasModuleProp) {
                r.isDriver = false;
                r.rejectReason = "缺少 module.prop";
                return r;
            }
            if (!hasRealKo) {
                r.isDriver = false;
                r.rejectReason = "不含有效 .ko 驱动文件";
                return r;
            }
            if (moduleId == null) {
                r.isDriver = false;
                r.rejectReason = "module.prop 缺少合法 id";
                return r;
            }

            r.isDriver = true;
            r.moduleId = moduleId;
            r.rejectReason = null;
            return r;

        } catch (Throwable t) {
            r.isDriver = false;
            r.rejectReason = "zip 打开失败: " + (t.getMessage() == null
                    ? t.getClass().getSimpleName() : t.getMessage());
            return r;
        }
    }

    private static boolean isSymlinkEntry(ZipEntry e) {
        byte[] extra = e.getExtra();
        if (extra == null || extra.length < 4) return false;

        int off = 0;
        while (off + 4 <= extra.length) {
            int headerId = (extra[off] & 0xFF) | ((extra[off + 1] & 0xFF) << 8);
            int dataSize = (extra[off + 2] & 0xFF) | ((extra[off + 3] & 0xFF) << 8);
            off += 4;

            if (off + dataSize > extra.length) return false;

            if (headerId == 0x000D && dataSize >= 12) {
                int modeOff = off + 8;
                int mode = (extra[modeOff] & 0xFF)
                        | ((extra[modeOff + 1] & 0xFF) << 8);
                if ((mode & 0xF000) == 0xA000) return true;
            }
            off += dataSize;
        }
        return false;
    }

    private boolean isRealKoEntry(ZipFile zf, ZipEntry e) {
        try {
            long size = e.getSize();
            if (size >= 0) {
                if (size < KO_MIN_SIZE) return false;
                if (size > KO_MAX_SIZE) return false;
            }

            try (InputStream is = zf.getInputStream(e)) {
                byte[] header = new byte[20];
                int off = 0;
                while (off < 20) {
                    int r = is.read(header, off, 20 - off);
                    if (r <= 0) return false;
                    off += r;
                }
                if (header[0] != 0x7F
                        || header[1] != 'E'
                        || header[2] != 'L'
                        || header[3] != 'F') return false;

                int eiClass   = header[4] & 0xFF;
                int eiData    = header[5] & 0xFF;
                int eiVersion = header[6] & 0xFF;

                if (eiClass != 1 && eiClass != 2) return false;
                if (eiData != 1 && eiData != 2) return false;
                if (eiVersion != 1) return false;

                int eType;
                int eMachine;
                if (eiData == 1) {
                    eType    = (header[16] & 0xFF) | ((header[17] & 0xFF) << 8);
                    eMachine = (header[18] & 0xFF) | ((header[19] & 0xFF) << 8);
                } else {
                    eType    = ((header[16] & 0xFF) << 8) | (header[17] & 0xFF);
                    eMachine = ((header[18] & 0xFF) << 8) | (header[19] & 0xFF);
                }

                if (eType != 1) return false;

                if (eMachine != 40 && eMachine != 183
                        && eMachine != 3 && eMachine != 62
                        && eMachine != 243) return false;

                return true;
            }
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isSafeModuleId(String id) {
        if (id == null || id.isEmpty()) return false;
        return MODULE_ID_SAFE_STRICT.matcher(id).matches();
    }

    private String readIdFromEntry(ZipFile zf, ZipEntry e) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(zf.getInputStream(e),
                        StandardCharsets.UTF_8))) {
            String line;
            int n = 0;
            while ((line = br.readLine()) != null && n++ < 500) {
                String t = line.trim();
                if (t.startsWith("id=")) {
                    String id = t.substring(3).trim();
                    if (!id.isEmpty()) return id;
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void onValidateFinished(String fileName, boolean isDriver,
                                    String rejectReason) {
        if (!isDriver) {
            isDriverFile = false;
            isShScript   = false;
            sessionInstalledZip = false;

            String reason = (rejectReason == null || rejectReason.isEmpty())
                    ? "非驱动文件" : rejectReason;

            tvStatus.setText("❌ " + reason);
            tvStatus.setTextColor(C_RED);
            appendLog("❌ 检测失败：" + reason, C_RED);
            btnStart.setText("无法刷入");
            btnStart.setBackground(createRoundRect(C_GRAY, dp(27)));
            btnStart.setEnabled(false);
            btnStart.setAlpha(0.5f);
            return;
        }

        isDriverFile = true;
        appendLog("✅ 检测通过", C_GREEN);

        if (isShScript) {
            moduleId = null;
            sessionInstalledZip = false;

            tvStatus.setText("⚠️ 脚本已扫描危险命令，刷入前会再次确认");
            tvStatus.setTextColor(C_ORANGE);
            needForce = false;
            updateStartButton("开始刷入", C_BLUE);
            return;
        }

        sessionInstalledZip = true;
        continueValidateForZip(fileName);
    }

    private void continueValidateForZip(String fileName) {
        String kernel = KernelDetector.getKernelVersion();
        if (kernel == null) kernel = "";

        if (!KernelDetector.isKernelMeasurable()
                || kernel.isEmpty()
                || "unknown".equalsIgnoreCase(kernel)) {
            tvStatus.setText("⚠️ 内核无法测量，跳过匹配");
            tvStatus.setTextColor(C_ORANGE);
            needForce = false;
            updateStartButton("开始刷入", C_BLUE);
            return;
        }

        String kernelMajor = extractMajor(kernel);
        boolean matches = nameMatchesKernel(fileName, kernelMajor);
        boolean universal = isUniversalName(fileName);

        if (matches) {
            tvStatus.setText("✅ 驱动有效，内核匹配");
            tvStatus.setTextColor(C_GREEN);
            appendLog("✅ 内核匹配通过", C_GREEN);
            needForce = false;
            updateStartButton("开始刷入", C_BLUE);
        } else if (universal) {
            tvStatus.setText("⚠️ 通用包，跳过内核匹配");
            tvStatus.setTextColor(C_ORANGE);
            appendLog("⚠️ 通用包（universal/all），不校验内核版本", C_ORANGE);
            appendLog("  · 请自行确认兼容性，误刷可能导致设备异常", C_ORANGE);
            needForce = true;
            updateStartButton("强制刷入", C_RED);
        } else {
            tvStatus.setText("⚠️ 驱动有效，但内核可能不匹配");
            tvStatus.setTextColor(C_ORANGE);
            appendLog("⚠️ 当前内核: " + kernel
                    + "（期望 " + kernelMajor + "）", C_ORANGE);
            needForce = true;
            updateStartButton("强制刷入", C_RED);
        }
    }

    private boolean isUniversalName(String fileName) {
        if (fileName == null) return false;
        String l = fileName.toLowerCase();
        if (l.matches(".*(^|[_.-])universal([_.-]|$).*")) return true;
        if (l.startsWith("universal.")) return true;
        if (l.startsWith("universal_") || l.startsWith("universal-")) return true;
        if (l.matches(".*[_-]anykernel([_.-]|$).*")) return true;
        if (l.matches(".*[_-]all\\.[a-z0-9]+$")) return true;
        if (l.matches(".*[_-]all[_-][a-z0-9]+\\.[a-z0-9]+$")) return true;
        return false;
    }

    private boolean nameMatchesKernel(String fileName, String kernelMajor) {
        if (kernelMajor == null || kernelMajor.isEmpty()
                || "unknown".equals(kernelMajor)) return false;
        Pattern p = Pattern.compile(
                "(^|[^0-9])" + Pattern.quote(kernelMajor) + "([^0-9]|$)");
        return p.matcher(fileName).find();
    }

    private void updateStartButton(String text, int color) {
        btnStart.setText(text);
        btnStart.setBackground(createRoundRect(color, dp(27)));
    }

    private String extractMajor(String kernel) {
        if (kernel == null || kernel.isEmpty()) return "unknown";
        String[] parts = kernel.split("\\.");
        if (parts.length >= 2 && !parts[0].isEmpty() && !parts[1].isEmpty()) {
            return parts[0] + "." + parts[1];
        }
        return parts[0].isEmpty() ? "unknown" : parts[0];
    }

    private String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = getContentResolver()
                    .query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) result = cursor.getString(idx);
                }
            } catch (Exception ignored) {}
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result == null ? "unknown" : result;
    }

    private void startFlash(boolean isForce) {
        if (selectedPath == null) {
            endFlash();
            return;
        }
        if (needForce && !isForce) {
            endFlash();
            return;
        }

        RootEnv.Info info = RootManager.get().getInfo();
        if (info.mode != RootEnv.MODE_GRANTED) {
            appendLog("❌ 未获得 Root 授权，无法执行刷入", C_RED);
            endFlash();
            return;
        }

        final long myToken = runToken.incrementAndGet();

        aborted       = false;
        hasDriverOp   = false;
        sawDoneMarker = false;

        btnCancel.setText("中止");

        appendLog("✅ " + info.typeName + " 已授权", C_GREEN);
        if (info.version != null && !info.version.isEmpty()) {
            appendLog("版本: " + info.version, C_SUB);
        }

        appendLog("\n[备份] 正在备份 boot 与驱动目录...", C_ORANGE);

        final RootEnv.Info fInfo = info;

        backupAll(success -> {
            if (runToken.get() != myToken || aborted) {
                appendLog("⚠️ 备份期间已取消，中止刷入", C_ORANGE);
                endFlash();
                return;
            }
            if (!success) {
                new AlertDialog.Builder(FlashActivity.this)
                        .setTitle("⚠️ 备份失败")
                        .setMessage("boot 或驱动目录备份失败，刷入失败将无法回滚，"
                                + "极可能导致手机无法开机（变砖）。\n\n确定继续吗？")
                        .setPositiveButton("继续刷入", (d, w) -> {
                            if (runToken.get() != myToken || aborted) {
                                endFlash();
                                return;
                            }
                            appendLog("\n第二层检测：实时监控刷入过程...\n", C_ORANGE);
                            String cmd = buildFlashCommand(fInfo.typeName,
                                    selectedPath);
                            appendLog("$ " + cmd, C_TEXT);
                            runFlashAsync(cmd, myToken);
                        })
                        .setNegativeButton("取消", (d, w) -> {
                            appendLog("用户取消，未刷入", C_ORANGE);
                            endFlash();
                        })
                        .setCancelable(false)
                        .show();
                return;
            }
            appendLog("\n第二层检测：实时监控刷入过程...\n", C_ORANGE);
            String cmd = buildFlashCommand(fInfo.typeName, selectedPath);
            appendLog("$ " + cmd, C_TEXT);
            runFlashAsync(cmd, myToken);
        });
    }

    private static String shellEscape(String s) {
        if (s == null || s.isEmpty()) return "''";
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private static boolean isSafeRootType(String t) {
        return "Magisk".equals(t) || "KernelSU".equals(t)
                || "APatch".equals(t);
    }

    private String buildFlashCommand(String rootType, String path) {
        if (path == null || path.isEmpty()) {
            return "echo 'ERROR: 路径为空'; exit 1";
        }
        String esc = shellEscape(path);

        if (isShScript) {
            return "chmod 755 " + esc + " && sh " + esc + "; "
                    + "ec=$?; [ $ec -eq 0 ] && echo FLASH_DONE_OK; exit $ec";
        }

        if (!isSafeRootType(rootType)) {
            return "echo 'ERROR: 未识别的 Root 类型'; exit 1";
        }

        if ("Magisk".equals(rootType)) {
            return "for m in /data/adb/magisk/magisk /debug_ramdisk/magisk "
                    + "/system/bin/magisk /sbin/magisk; do "
                    + "[ -x \"$m\" ] && MAGISK=\"$m\" && break; done; "
                    + "[ -z \"$MAGISK\" ] && echo 'ERROR: magisk not found' && exit 1; "
                    + "\"$MAGISK\" --install-module " + esc + "; "
                    + "ec=$?; [ $ec -eq 0 ] && echo FLASH_DONE_OK; exit $ec";

        } else if ("KernelSU".equals(rootType)) {
            return "KSUD=$(command -v ksud 2>/dev/null); "
                    + "[ -z \"$KSUD\" ] && KSUD=/data/adb/ksu/bin/ksud; "
                    + "[ ! -x \"$KSUD\" ] && echo 'ERROR: ksud not found' && exit 1; "
                    + "\"$KSUD\" module install " + esc + " 2>&1 || "
                    + "\"$KSUD\" module install --zip " + esc + " 2>&1; "
                    + "ec=$?; [ $ec -eq 0 ] && echo FLASH_DONE_OK; exit $ec";

        } else {
            return "for m in /data/adb/magisk/magisk /data/adb/ap/bin/magisk "
                    + "/system/bin/magisk; do "
                    + "[ -x \"$m\" ] && MAGISK=\"$m\" && break; done; "
                    + "[ -z \"$MAGISK\" ] && echo 'ERROR: apatch magisk-compat not found' && exit 1; "
                    + "\"$MAGISK\" --install-module " + esc + "; "
                    + "ec=$?; [ $ec -eq 0 ] && echo FLASH_DONE_OK; exit $ec";
        }
    }

    private interface BoolCallback {
        void onResult(boolean success);
    }

    private void backupAll(final BoolCallback onFinish) {
        String script =
                "BK=/sdcard/DriverBackup\n" +
                "mkdir -p $BK || { echo '[备份] ⚠️ 创建备份目录失败'; exit 1; }\n" +
                "echo \"[备份] $(date)\"\n" +
                "SLOT=$(getprop ro.boot.slot_suffix 2>/dev/null)\n" +
                "BOOT_PART=\"\"\n" +
                "if [ -n \"$SLOT\" ] && [ -e /dev/block/by-name/boot$SLOT ]; then\n" +
                "  BOOT_PART=boot$SLOT\n" +
                "else\n" +
                "  for p in boot_a boot_b boot; do\n" +
                "    [ -e /dev/block/by-name/$p ] && BOOT_PART=$p && break\n" +
                "  done\n" +
                "fi\n" +
                "case $BOOT_PART in\n" +
                "  boot|boot_a|boot_b) ;;\n" +
                "  *) BOOT_PART=\"\" ;;\n" +
                "esac\n" +
                "BOOT_OK=0\n" +
                "if [ -n \"$BOOT_PART\" ]; then\n" +
                "  SRC=/dev/block/by-name/$BOOT_PART\n" +
                "  SZ=$(blockdev --getsize64 \"$SRC\" 2>/dev/null)\n" +
                "  if dd if=\"$SRC\" of=$BK/boot_backup.img 2>/dev/null; then\n" +
                "    FILE_SZ=$(wc -c < $BK/boot_backup.img 2>/dev/null)\n" +
                "    if [ -n \"$SZ\" ] && [ \"$FILE_SZ\" = \"$SZ\" ] && [ \"$FILE_SZ\" -gt 0 ]; then\n" +
                "      BOOT_OK=1\n" +
                "      echo \"[备份] boot -> boot_backup.img ($BOOT_PART, $FILE_SZ bytes)\"\n" +
                "    elif [ -z \"$SZ\" ] && [ \"$FILE_SZ\" -gt 0 ]; then\n" +
                "      BOOT_OK=1\n" +
                "      echo \"[备份] boot -> boot_backup.img ($BOOT_PART, 未校验大小)\"\n" +
                "    else\n" +
                "      echo \"[备份] ⚠️ boot 备份不完整 ($FILE_SZ / $SZ)\"\n" +
                "    fi\n" +
                "  else\n" +
                "    echo \"[备份] ⚠️ boot 备份失败 ($BOOT_PART)\"\n" +
                "  fi\n" +
                "else\n" +
                "  echo '[备份] 未找到 boot 分区'\n" +
                "fi\n" +
                "DIRS_OK=0\n" +
                "DIRS_TOTAL=0\n" +
                "for d in /data/adb/modules /vendor/lib/modules /system/lib/modules /lib/modules; do\n" +
                "  [ -d $d ] || continue\n" +
                "  DIRS_TOTAL=$((DIRS_TOTAL + 1))\n" +
                "  NAME=$(echo $d | tr '/' '_')\n" +
                "  rm -rf $BK/$NAME\n" +
                "  if cp -r $d $BK/$NAME 2>/dev/null; then\n" +
                "    DIRS_OK=$((DIRS_OK + 1))\n" +
                "    echo \"[备份] $d\"\n" +
                "  else\n" +
                "    echo \"[备份] ⚠️ $d 备份失败\"\n" +
                "  fi\n" +
                "done\n" +
                "MODLIST_OK=0\n" +
                "if [ -d /data/adb/modules ]; then\n" +
                "  if ls /data/adb/modules > $BK/modules.list 2>/dev/null; then\n" +
                "    MODLIST_OK=1\n" +
                "  else\n" +
                "    echo \"[备份] ⚠️ 模块列表写入失败\"\n" +
                "  fi\n" +
                "fi\n" +
                "echo \"[备份] 摘要 BOOT_OK=$BOOT_OK DIRS_OK=$DIRS_OK DIRS_TOTAL=$DIRS_TOTAL MODLIST_OK=$MODLIST_OK\"\n" +
                "echo '[备份] 完成'\n";

        RootHelper.runAsync(script, BACKUP_TIMEOUT_SEC, r -> {
            if (!canTouchUi()) {
                if (onFinish != null) onFinish.onResult(false);
                return;
            }

            String out = r.stdout == null ? "" : r.stdout;
            boolean completed  = out.contains("[备份] 完成");
            boolean bootOk     = out.contains("BOOT_OK=1");
            boolean dirsFailed = out.contains("⚠️") && out.contains("备份失败");
            boolean modListFail = out.contains("模块列表写入失败");

            int dirsOkVal    = parseKv(out, "DIRS_OK=");
            int dirsTotalVal = parseKv(out, "DIRS_TOTAL=");
            boolean dirsOk = false;
            if (dirsOkVal >= 0 && dirsTotalVal >= 0) {
                dirsOk = (dirsTotalVal == 0) || (dirsOkVal == dirsTotalVal);
            }

            boolean ok = r.ok()
                    && completed
                    && bootOk
                    && dirsOk
                    && !dirsFailed
                    && !modListFail;

            if (ok) {
                appendLog("✅ 备份完成", C_GREEN);
                if (onFinish != null) onFinish.onResult(true);
            } else {
                appendLog("⚠️ 备份失败或部分失败", C_ORANGE);
                if (r.error != null) appendLog("原因: " + r.error, C_SUB);
                if (!bootOk && !out.contains("未找到 boot 分区")) {
                    appendLog("  · boot 备份不完整或失败", C_SUB);
                }
                if (!dirsOk) {
                    appendLog("  · 驱动目录 " + Math.max(0, dirsOkVal) + "/"
                            + Math.max(0, dirsTotalVal) + " 备份成功", C_SUB);
                }
                if (modListFail) {
                    appendLog("  · 模块列表写入失败", C_SUB);
                }
                if (onFinish != null) onFinish.onResult(false);
            }
        });
    }

    private static boolean isDriverOpLine(String line) {
        if (line == null) return false;
        String t = line.trim();

        if (t.startsWith("sudo "))    t = t.substring(5).trim();
        if (t.startsWith("busybox ")) t = t.substring(8).trim();
        if (t.startsWith("toybox "))  t = t.substring(7).trim();

        if (t.startsWith("echo ")   || t.startsWith("echo\t"))   return false;
        if (t.startsWith("printf ") || t.startsWith("printf\t")) return false;
        if (t.startsWith("#")) return false;
        if (t.startsWith("+ ") || t.startsWith("+")) return false;

        if (t.startsWith("insmod ")   || t.startsWith("insmod\t"))   return true;
        if (t.startsWith("rmmod ")    || t.startsWith("rmmod\t"))    return true;
        if (t.startsWith("modprobe ") || t.startsWith("modprobe\t")) return true;

        if (t.contains("magisk") && t.contains("--install-module")) return true;
        if (t.contains("ksud")   && t.contains("module install"))   return true;

        return false;
    }

    private void runFlashAsync(final String cmd, final long myToken) {
        stopWatchdog();

        new Thread(() -> {
            hasDriverOp    = false;
            sawDoneMarker  = false;
            flashStartTime = System.currentTimeMillis();
            lastOutputTime = flashStartTime;

            Process p = null;
            try {
                ProcessBuilder pb = new ProcessBuilder("su", "-c", cmd);
                pb.redirectErrorStream(true);
                p = pb.start();

                if (runToken.get() != myToken) {
                    RootHelper.killCompat(p);
                    return;
                }
                currentProcess = p;

                startWatchdog(myToken);

                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {

                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (runToken.get() != myToken) return;

                        lastOutputTime = System.currentTimeMillis();

                        if (isDriverOpLine(line)) {
                            hasDriverOp = true;
                        }
                        if (line.contains("FLASH_DONE_OK")
                                || line.contains("—— 刷入完成 ——")) {
                            sawDoneMarker = true;
                        }

                        if (aborted) return;

                        final String l = line;
                        appendLog(l, C_TEXT);
                    }
                }

                int exit = waitForExit(p, WAIT_EXIT_MS);
                stopWatchdog();

                if (runToken.get() != myToken) return;

                if (exit == -1) {
                    RootHelper.killCompat(p);
                    MAIN.post(() -> {
                        if (runToken.get() != myToken) return;
                        if (!canTouchUi() || aborted) return;
                        appendLog("\n⚠️ 进程超时未退出，已强制终止", C_RED);
                        endFlash();
                    });
                    return;
                }

                boolean realSuccess = (exit == 0) && (hasDriverOp || sawDoneMarker);

                final int fexit = exit;
                final boolean fReal = realSuccess;

                MAIN.post(() -> {
                    if (runToken.get() != myToken) return;
                    if (!canTouchUi() || aborted) return;
                    if (fReal) {
                        appendLog("\n✅ 脚本执行完成 (exit=" + fexit + ")", C_GREEN);
                        verifyAfterFlash(myToken);
                    } else {
                        appendLog("\n⚠️ 警告：脚本中途退出或未完成，驱动可能没装完 (exit="
                                + fexit + ")", C_RED);
                        appendLog("建议：重启前先进入 Recovery", C_ORANGE);
                        endFlash();
                    }
                });
            } catch (Exception e) {
                stopWatchdog();
                if (runToken.get() != myToken) return;
                final String msg = e.getMessage();
                MAIN.post(() -> {
                    if (runToken.get() != myToken) return;
                    if (!canTouchUi()) return;
                    if (aborted) {
                        appendLog("ℹ️ 刷入已中止", C_ORANGE);
                    } else {
                        appendLog("错误: " + msg, C_RED);
                    }
                    endFlash();
                });
            } finally {
                if (runToken.get() == myToken) {
                    currentProcess = null;
                }
            }
        }).start();
    }

    private void verifyAfterFlash(final long myToken) {
        appendLog("正在校验模块加载状态...", C_SUB);

        String check =
                "echo '---MODULES---' ; "
                + "if [ -d /data/adb/modules ]; then "
                + "  ls -1 /data/adb/modules 2>/dev/null | wc -l ; "
                + "else echo MISSING ; fi ; "
                + "echo '---KOMODS---' ; "
                + "CNT=$(for d in /vendor/lib/modules /system/lib/modules /lib/modules; do "
                + "  [ -d \"$d\" ] || continue ; "
                + "  find \"$d\" -maxdepth 1 -name '*.ko' -type f 2>/dev/null ; "
                + "done | wc -l) ; echo $CNT";

        RootHelper.runAsync(check, VERIFY_TIMEOUT_SEC, r -> {
            if (runToken.get() != myToken) return;
            if (!canTouchUi()) return;

            if (!r.ok() && (r.stdout == null || r.stdout.isEmpty())) {
                appendLog("ℹ️ 校验未执行，无法确认模块状态", C_SUB);
                endFlash();
                fixSelinuxContextAsync();
                return;
            }

            String out = r.stdout == null ? "" : r.stdout;
            String modSeg = extractSegment(out, "---MODULES---", "---KOMODS---");
            String koSeg  = extractSegment(out, "---KOMODS---", null);

            if (modSeg == null && koSeg == null) {
                appendLog("ℹ️ 校验输出无法解析，跳过确认", C_SUB);
                endFlash();
                fixSelinuxContextAsync();
                return;
            }

            boolean modMissing = (modSeg != null)
                    && modSeg.trim().contains("MISSING");
            int modulesCount = (modSeg == null || modMissing)
                    ? -1 : parseIntSafe(modSeg.trim());
            int koCount = (koSeg == null) ? -1 : parseIntSafe(koSeg.trim());

            if (koCount == -1) {
                if (modulesCount > 0) {
                    appendLog("ℹ️ 模块目录已有 " + modulesCount + " 项，.ko 校验未完成", C_SUB);
                    appendLog("  · 建议重启后确认驱动是否生效", C_SUB);
                } else {
                    appendLog("⚠️ .ko 文件校验未完成，无法确认模块状态", C_ORANGE);
                }
            } else if (modMissing) {
                if (koCount > 0) {
                    appendLog("⚠️ 模块目录不存在，但检测到 .ko 文件", C_ORANGE);
                    appendLog("  · 可能是系统自带 / 旧残留 / 脚本直接写入 vendor", C_ORANGE);
                    appendLog("  · 刷入可能未生效", C_ORANGE);
                } else if (koCount == 0) {
                    appendLog("⚠️ 模块目录与 .ko 均未检测到，可能未真正生效", C_ORANGE);
                } else {
                    appendLog("ℹ️ 模块目录不存在，.ko 校验未完成", C_SUB);
                }
            } else if (modulesCount == -1) {
                if (koCount > 0) {
                    appendLog("✅ 检测到 .ko 文件已就位", C_GREEN);
                } else if (koCount == 0) {
                    appendLog("⚠️ 未检测到 .ko 文件，可能未真正生效", C_ORANGE);
                }
            } else if ((modulesCount > 0) || (koCount > 0)) {
                appendLog("✅ 刷入成功，模块文件已就位", C_GREEN);
            } else if (modulesCount == 0 && koCount == 0) {
                appendLog("⚠️ 脚本报成功，但未检测到模块文件，可能未真正生效", C_ORANGE);
                appendLog("建议：重启前先进入 Recovery", C_ORANGE);
            } else {
                appendLog("⚠️ 校验结果不完整，无法确认模块状态", C_ORANGE);
            }
            endFlash();
            fixSelinuxContextAsync();
        });
    }

    private static String extractSegment(String out, String startMark, String endMark) {
        if (out == null || startMark == null) return null;
        int idx = out.indexOf(startMark);
        if (idx < 0) return null;
        int from = idx + startMark.length();
        int to = (endMark == null) ? out.length() : out.indexOf(endMark, from);
        if (to < 0) {
            if (endMark != null) return null;
            to = out.length();
        }
        return out.substring(from, to).trim();
    }

    private static int parseIntSafe(String seg) {
        if (seg == null) return -1;
        for (String tok : seg.split("\\s+")) {
            try {
                return Integer.parseInt(tok);
            } catch (NumberFormatException ignored) {}
        }
        return -1;
    }

    private static int waitForExit(Process p, long timeoutMs) {
        if (p == null) return -1;
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            try {
                return p.exitValue();
            } catch (IllegalThreadStateException ignored) {
            } catch (Throwable t) {
                return -1;
            }
            try { Thread.sleep(50L); }
            catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return -1;
            }
        }
        return -1;
    }

    private void startWatchdog(final long token) {
        watchdogFuture = WATCHDOG.scheduleWithFixedDelay(() -> {
            try {
                if (runToken.get() != token) return;
                if (aborted || hasDriverOp) return;

                long now = System.currentTimeMillis();
                if (now - lastOutputTime > SILENT_ABORT_MS
                        && now - flashStartTime > SILENT_ABORT_MS) {

                    if (aborted) return;
                    aborted = true;
                    appendLog("\n⚠️ 30 秒无输出，watchdog 强杀进程", C_RED);
                    killProcessNow();

                    MAIN.post(() -> {
                        if (runToken.get() != token) return;
                        if (canTouchUi()) onRuntimeAbort();
                    });
                }
            } catch (Throwable ignored) {}
        }, WATCHDOG_TICK_MS, WATCHDOG_TICK_MS, TimeUnit.MILLISECONDS);
    }

    private void stopWatchdog() {
        ScheduledFuture<?> f = watchdogFuture;
        watchdogFuture = null;
        if (f != null) {
            try { f.cancel(false); } catch (Throwable ignored) {}
        }
    }

    private void fixSelinuxContextAsync() {
        final long myToken = runToken.get();

        String fix =
                "TMP=\"\" ; "
                + "if command -v mktemp >/dev/null 2>&1; then "
                + "  TMP=$(mktemp /data/local/tmp/.selinux_list.XXXXXX 2>/dev/null) ; "
                + "fi ; "
                + "if [ -z \"$TMP\" ]; then "
                + "  TMP=/data/local/tmp/.selinux_list.$$ ; "
                + "fi ; "
                + "if [ -L \"$TMP\" ]; then "
                + "  echo \"SELINUX_FAIL tmp\" ; exit 0 ; "
                + "fi ; "
                + ": > \"$TMP\" || { echo \"SELINUX_FAIL tmp\" ; exit 0 ; } ; "
                + "FIND_FAIL=0 ; "
                + "for d in /vendor/lib/modules /system/lib/modules /lib/modules; do "
                + "  [ -d \"$d\" ] || continue ; "
                + "  find \"$d\" -maxdepth 1 -name '*.ko' -type f 2>/dev/null >> \"$TMP\" "
                + "    || FIND_FAIL=1 ; "
                + "done ; "
                + "if [ $FIND_FAIL -eq 1 ]; then "
                + "  if [ ! -s \"$TMP\" ]; then "
                + "    rm -f \"$TMP\" ; echo \"SELINUX_FAIL find\" ; exit 0 ; "
                + "  else "
                + "    echo \"SELINUX_PARTIAL find\" ; "
                + "  fi ; "
                + "fi ; "
                + "FAIL=0; CNT=0 ; "
                + "while IFS= read -r f; do "
                + "  [ -n \"$f\" ] || continue ; "
                + "  CNT=$((CNT + 1)) ; "
                + "  chcon u:object_r:vendor_file:s0 \"$f\" 2>/dev/null "
                + "    || FAIL=$((FAIL + 1)) ; "
                + "  [ $CNT -ge 500 ] && break ; "
                + "done < \"$TMP\" ; "
                + "rm -f \"$TMP\" ; "
                + "sync ; "
                + "echo \"SELINUX_DONE CNT=$CNT FAIL=$FAIL\"";

        RootHelper.runAsync(fix, SELINUX_TIMEOUT_SEC, r -> {
            if (runToken.get() != myToken) return;
            if (!canTouchUi()) return;

            String out = r.stdout == null ? "" : r.stdout;

            if (out.contains("SELINUX_FAIL tmp")) {
                appendLog("ℹ️ SELinux 修复跳过（临时文件不可用）", C_SUB);
                return;
            }
            if (out.contains("SELINUX_FAIL find")) {
                appendLog("ℹ️ SELinux 修复跳过（查找 .ko 失败）", C_SUB);
                return;
            }
            if (out.contains("SELINUX_PARTIAL")) {
                appendLog("⚠️ 部分目录查找失败，SELinux 修复可能不完整", C_ORANGE);
            }
            if (!out.contains("SELINUX_DONE")) {
                appendLog("ℹ️ SELinux 上下文修复未执行", C_SUB);
                return;
            }

            int cnt  = parseKv(out, "CNT=");
            int fail = parseKv(out, "FAIL=");

            if (cnt == 0) {
                appendLog("ℹ️ 未找到 .ko 文件，跳过 SELinux 修复", C_SUB);
                return;
            }
            if (fail == 0) {
                appendLog("✅ 已修复 SELinux 上下文（" + cnt + " 个）", C_GREEN);
            } else if (fail == cnt) {
                appendLog("ℹ️ SELinux 上下文修复跳过（全部失败，可能只读分区）", C_SUB);
            } else {
                appendLog("⚠️ SELinux 上下文部分失败（"
                        + (cnt - fail) + "/" + cnt + " 成功）", C_ORANGE);
            }
        });
    }

    private static int parseKv(String out, String key) {
        if (out == null || key == null) return -1;
        int idx = out.indexOf(key);
        if (idx < 0) return -1;
        int from = idx + key.length();
        int to = from;
        while (to < out.length() && Character.isDigit(out.charAt(to))) to++;
        if (to == from) return -1;
        try {
            return Integer.parseInt(out.substring(from, to));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void onRuntimeAbort() {
        stopWatchdog();
        appendLog("\n⚠️ 第二层检测：长时间无输出，已中止", C_RED);

        btnStart.setEnabled(false);
        btnStart.setAlpha(0.5f);
        btnCancel.setEnabled(false);
        btnCancel.setAlpha(0.5f);

        final boolean[] handled = {false};

        AlertDialog d = new AlertDialog.Builder(FlashActivity.this)
                .setTitle("⚠️ 驱动异常")
                .setMessage("刷入过程中未检测到真实的驱动操作，且长时间无输出。\n\n"
                        + "这可能不是有效的驱动包。\n\n请选择：")
                .setPositiveButton("我已知晓风险，继续刷入", (dlg, w) -> {
                    handled[0] = true;
                    RootEnv.Info info = RootManager.get().getInfo();
                    if (info.mode != RootEnv.MODE_GRANTED) {
                        appendLog("❌ Root 授权已失效，无法继续刷入", C_RED);
                        endFlash();
                        return;
                    }

                    appendLog("用户选择继续刷入...", C_ORANGE);
                    aborted = false;
                    hasDriverOp = false;
                    sawDoneMarker = false;

                    btnStart.setEnabled(false);
                    btnStart.setAlpha(0.5f);
                    btnCancel.setEnabled(true);
                    btnCancel.setAlpha(1f);
                    btnCancel.setText("中止");

                    String cmd = buildFlashCommand(info.typeName, selectedPath);
                    final long newToken = runToken.incrementAndGet();
                    runFlashAsync(cmd, newToken);
                })
                .setNegativeButton("取消并删除", (dlg, w) -> {
                    handled[0] = true;
                    deleteInstalledFiles();
                    appendLog("用户取消，已删除相关文件", C_ORANGE);
                    endFlash();
                    finish();
                })
                .setOnCancelListener(dlg -> {
                    handled[0] = true;
                    endFlash();
                })
                .setCancelable(false)
                .create();
        d.setOnDismissListener(dlg -> {
            if (!handled[0]) endFlash();
        });
        d.show();
    }

    private void deleteInstalledFiles() {
        if (selectedPath == null) return;

        String pathEsc = shellEscape(selectedPath);

        String id = sessionInstalledZip ? moduleId : null;

        if (id == null || id.isEmpty()
                || !MODULE_ID_SAFE_STRICT.matcher(id).matches()) {
            String cmd = "rm -f " + pathEsc + " 2>/dev/null; echo done";
            RootHelper.runAsync(cmd, DELETE_TIMEOUT_SEC,
                    r -> appendLog(r.all(), C_SUB));
            return;
        }

        String cmd =
                "rm -rf " + shellEscape("/data/adb/modules/" + id) + " 2>/dev/null; " +
                "rm -rf " + shellEscape("/data/adb/modules_update/" + id) + " 2>/dev/null; " +
                "rm -f " + pathEsc + " 2>/dev/null; " +
                "echo done";
        RootHelper.runAsync(cmd, DELETE_TIMEOUT_SEC,
                r -> appendLog(r.all(), C_SUB));
    }

    private void endFlash() {
        synchronized (flashLock) {
            flashing = false;
        }
        MAIN.post(() -> {
            if (!canTouchUi()) return;
            btnStart.setEnabled(true);
            btnStart.setAlpha(1f);
            btnCancel.setEnabled(true);
            btnCancel.setAlpha(1f);
            btnCancel.setText("取消");
        });
    }

    private void killProcessNow() {
        final Process p = currentProcess;
        currentProcess = null;
        if (p == null) return;
        RootHelper.killCompat(p);
    }

    private void appendLog(String text, int color) {
        if (pendingLogCount.get() >= MAX_PENDING_LOGS) {
            droppedLogCount.incrementAndGet();
            return;
        }

        pendingLogCount.incrementAndGet();
        final String fText = text;
        final int fColor = color;

        MAIN.postAtTime(() -> {
            try {
                int dropped = droppedLogCount.getAndSet(0);
                if (dropped > 0) {
                    appendLogOnMain("… 已省略 " + dropped + " 行日志", C_SUB);
                }
                appendLogOnMain(fText, fColor);
            } finally {
                pendingLogCount.decrementAndGet();
            }
        }, LOG_TOKEN, SystemClock.uptimeMillis());
    }

    private void appendLogOnMain(String text, int color) {
        if (logContainer == null || !canTouchUi()) return;

        while (logContainer.getChildCount() >= MAX_LOG_LINES) {
            logContainer.removeViewAt(0);
        }

        TextView line = new TextView(this);
        line.setText(text);
        line.setTextSize(13);
        line.setTextColor(color);
        line.setTypeface(Typeface.MONOSPACE);
        line.setPadding(0, dp(3), 0, dp(3));
        logContainer.addView(line);

        if (!scrollPending) {
            scrollPending = true;
            logScroll.postDelayed(() -> {
                scrollPending = false;
                if (canTouchUi()) {
                    logScroll.fullScroll(View.FOCUS_DOWN);
                }
            }, 80);
        }
    }

    private void applyCardStyle(View view) {
        GradientDrawable bg = createRoundRect(C_CARD, dp(20));
        bg.setStroke(dp(1), CARD_STROKE_COLOR);
        view.setBackground(bg);
        view.setElevation(dp(2));
    }

    private void setPressFeedback(View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            private boolean pressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!pressed) {
                            pressed = true;
                            vibrate();
                        }
                        v.animate().scaleX(0.95f).scaleY(0.95f).alpha(0.85f)
                                .setDuration(80)
                                .setInterpolator(new DecelerateInterpolator())
                                .start();
                        break;

                    case MotionEvent.ACTION_MOVE: {
                        boolean inside = isInside(v, event);
                        if (pressed && !inside) {
                            pressed = false;
                            v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                                    .setDuration(150).start();
                        } else if (!pressed && inside) {
                            pressed = true;
                            vibrate();
                            v.animate().scaleX(0.95f).scaleY(0.95f).alpha(0.85f)
                                    .setDuration(80).start();
                        }
                        break;
                    }

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        boolean wasPressed = pressed;
                        pressed = false;
                        v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                                .setDuration(350)
                                .setInterpolator(new OvershootInterpolator(2.5f))
                                .start();
                        if (event.getActionMasked() == MotionEvent.ACTION_UP
                                && wasPressed && isInside(v, event)) {
                            v.performClick();
                        }
                        break;
                    }
                }
                return true;
            }

            private boolean isInside(View v, MotionEvent e) {
                float x = e.getX(), y = e.getY();
                return x >= 0 && x <= v.getWidth()
                        && y >= 0 && y <= v.getHeight();
            }
        });
    }

    private void vibrate() {
        try {
            View root = findViewById(android.R.id.content);
            if (root != null) {
                root.performHapticFeedback(
                        HapticFeedbackConstants.VIRTUAL_KEY,
                        HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
            }
        } catch (Exception ignored) {}
    }

    private GradientDrawable createRoundRect(int color, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(color);
        d.setCornerRadius(radiusPx);
        return d;
    }

    private int dp(float dpValue) {
        return (int) (dpValue * density + 0.5f);
    }
}