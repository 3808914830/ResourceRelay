package com.demo.controlcenter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 自定义外观页。
 *
 * 本版修复：
 *  1. ★ saveScaledIcon 的 finally 只在失败时 recycle：
 *     成功时把 Bitmap 所有权交给调用方，不再无条件回收
 *     （旧版依赖"调用方重新读 PNG"的隐式契约，脆弱）
 *  2. ★ inPreferredConfig 按 MIME 选：
 *     JPG → RGB_565（省一半内存），PNG/GIF → ARGB_8888（保透明）
 *  3. ★ Intent 加 FLAG_GRANT_READ_URI_PERMISSION
 *  4. ★ busy 复位时机改到 IO 任务 finally，避免 MAIN.post 被移除时卡死
 *  5. 保留上一版：降采样到 512、inJustDecodeBounds、防重入、canTouchUi、
 *     InputFilter 限名字长度、onDestroy 清 Handler
 */
public class CustomActivity extends Activity {

    private float density;
    private final Handler MAIN = new Handler(Looper.getMainLooper());
    private final ExecutorService IO_POOL = Executors.newSingleThreadExecutor();

    private ImageView previewIcon;
    private EditText inputName;

    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean destroyed = false;

    private static final int REQ_PICK_ICON = 4001;

    /** 图标存盘最大边长（px），防 OOM */
    private static final int ICON_MAX_SIZE = 512;
    /** 名字长度上限 */
    private static final int NAME_MAX_LEN = 20;

    // ===== 颜色 =====
    private static final String COLOR_BG     = "#F2F2F7";
    private static final String COLOR_CARD   = "#FFFFFF";
    private static final String COLOR_TEXT   = "#1C1C1E";
    private static final String COLOR_SUB    = "#8E8E93";
    private static final String COLOR_BLUE   = "#007AFF";
    private static final String COLOR_WHITE  = "#FFFFFF";
    private static final String BG_ICON      = "#E3F0FF";

    private static final int CARD_STROKE_COLOR = 0x0F000000;

    // ============================================================
    // 生命周期
    // ============================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        buildUI();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        MAIN.removeCallbacksAndMessages(null);
        try { IO_POOL.shutdownNow(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private boolean canTouchUi() {
        return !destroyed && !isFinishing() && !isDestroyed();
    }

    private void safeToast(String msg, int duration) {
        if (!canTouchUi()) return;
        try {
            Toast.makeText(this, msg, duration).show();
        } catch (Throwable ignored) {}
    }

    // ============================================================
    // UI
    // ============================================================
    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor(COLOR_BG));
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView btnBack = new TextView(this);
        btnBack.setText("‹ 返回");
        btnBack.setTextSize(16);
        btnBack.setTextColor(Color.parseColor(COLOR_BLUE));
        btnBack.setContentDescription("返回");
        btnBack.setOnClickListener(v -> { vibrate(); finish(); });
        root.addView(btnBack);

        TextView title = new TextView(this);
        title.setText("自定义外观");
        title.setTextSize(22);
        title.setTextColor(Color.parseColor(COLOR_TEXT));
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(16);
        tp.bottomMargin = dp(24);
        title.setLayoutParams(tp);
        root.addView(title);

        root.addView(buildIconCard());
        root.addView(buildNameCard());
        root.addView(buildSaveButton());
        root.addView(buildResetButton());

        setContentView(root);
    }

    private LinearLayout buildIconCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(20), dp(24), dp(20), dp(24));
        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        applyCardStyle(card);

        TextView label = new TextView(this);
        label.setText("应用图标");
        label.setTextSize(13);
        label.setTextColor(Color.parseColor(COLOR_SUB));
        card.addView(label);

        previewIcon = new ImageView(this);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(80), dp(80));
        ip.topMargin = dp(16);
        previewIcon.setLayoutParams(ip);
        previewIcon.setBackground(createRoundRect(BG_ICON, dp(16)));
        previewIcon.setPadding(dp(12), dp(12), dp(12), dp(12));
        previewIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);

        loadPreviewAsync();

        card.addView(previewIcon);

        TextView btnPick = new TextView(this);
        btnPick.setText("选择图片");
        btnPick.setTextSize(15);
        btnPick.setTextColor(Color.parseColor(COLOR_WHITE));
        btnPick.setTypeface(null, Typeface.BOLD);
        btnPick.setGravity(Gravity.CENTER);
        btnPick.setContentDescription("选择图标");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        bp.topMargin = dp(16);
        btnPick.setLayoutParams(bp);
        btnPick.setBackground(createRoundRect(COLOR_BLUE, dp(24)));
        btnPick.setOnClickListener(v -> {
            vibrate();
            pickIcon();
        });
        setPressFeedback(btnPick);
        card.addView(btnPick);

        return card;
    }

    private LinearLayout buildNameCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        np.topMargin = dp(16);
        card.setLayoutParams(np);
        applyCardStyle(card);

        TextView label = new TextView(this);
        label.setText("应用名称");
        label.setTextSize(13);
        label.setTextColor(Color.parseColor(COLOR_SUB));
        card.addView(label);

        inputName = new EditText(this);
        inputName.setText(CustomManager.getName(this));
        inputName.setTextSize(16);
        inputName.setTextColor(Color.parseColor(COLOR_TEXT));
        inputName.setBackground(null);
        inputName.setSingleLine(true);
        inputName.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(NAME_MAX_LEN)
        });
        inputName.setHint("输入应用名称");
        inputName.setHintTextColor(Color.parseColor(COLOR_SUB));
        LinearLayout.LayoutParams eip = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        eip.topMargin = dp(12);
        inputName.setLayoutParams(eip);
        card.addView(inputName);

        return card;
    }

    private TextView buildSaveButton() {
        TextView btnSave = new TextView(this);
        btnSave.setText("保存");
        btnSave.setTextSize(16);
        btnSave.setTextColor(Color.parseColor(COLOR_WHITE));
        btnSave.setTypeface(null, Typeface.BOLD);
        btnSave.setGravity(Gravity.CENTER);
        btnSave.setContentDescription("保存");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        sp.topMargin = dp(24);
        btnSave.setLayoutParams(sp);
        btnSave.setBackground(createRoundRect(COLOR_BLUE, dp(28)));
        btnSave.setOnClickListener(v -> {
            vibrate();
            saveCustom();
        });
        setPressFeedback(btnSave);
        return btnSave;
    }

    private TextView buildResetButton() {
        TextView btnReset = new TextView(this);
        btnReset.setText("恢复默认");
        btnReset.setTextSize(14);
        btnReset.setTextColor(Color.parseColor(COLOR_SUB));
        btnReset.setGravity(Gravity.CENTER);
        btnReset.setContentDescription("恢复默认");
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        rp.topMargin = dp(12);
        btnReset.setLayoutParams(rp);
        btnReset.setOnClickListener(v -> {
            vibrate();
            confirmReset();
        });
        setPressFeedback(btnReset);
        return btnReset;
    }

    // ============================================================
    // 图标加载
    // ============================================================
    private void loadPreviewAsync() {
        IO_POOL.execute(() -> {
            final Bitmap bmp = CustomManager.loadIcon(CustomActivity.this);
            MAIN.post(() -> {
                if (!canTouchUi() || previewIcon == null) {
                    if (bmp != null && !bmp.isRecycled()) bmp.recycle();
                    return;
                }
                if (bmp != null) {
                    previewIcon.setImageBitmap(bmp);
                } else {
                    previewIcon.setImageResource(
                            android.R.drawable.ic_menu_manage);
                }
            });
        });
    }

    // ============================================================
    // 选图
    // ============================================================
    private void pickIcon() {
        if (busy.get()) return;

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(
                    Intent.createChooser(intent, "选择图标"),
                    REQ_PICK_ICON);
        } catch (Throwable t) {
            safeToast("没有可用的文件管理器", Toast.LENGTH_SHORT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_ICON) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        final Uri uri = data.getData();
        if (!busy.compareAndSet(false, true)) return;

        IO_POOL.execute(() -> {
            String path = null;
            Bitmap bmp = null;
            try {
                path = saveScaledIcon(uri);
                if (path != null) {
                    CustomManager.setIconPath(CustomActivity.this, path);
                    bmp = CustomManager.loadIcon(CustomActivity.this);
                }
            } finally {
                // ★ busy 在 IO 任务结束时就复位，不依赖 MAIN.post
                busy.set(false);
            }

            final boolean ok = (path != null);
            final Bitmap fbmp = bmp;
            MAIN.post(() -> {
                if (!canTouchUi()) {
                    if (fbmp != null && !fbmp.isRecycled()) fbmp.recycle();
                    return;
                }
                if (ok && fbmp != null && previewIcon != null) {
                    previewIcon.setImageBitmap(fbmp);
                    safeToast("图标已保存", Toast.LENGTH_SHORT);
                } else {
                    safeToast("图标保存失败", Toast.LENGTH_SHORT);
                }
            });
        });
    }

    /**
     * 读 URI → 降采样到 ≤ ICON_MAX_SIZE → 存成 PNG。
     *
     * ★ 关键修复：
     *   - finally 只在失败路径 recycle，成功时把 Bitmap 所有权交给调用方
     *   - inPreferredConfig 按 MIME 选：JPG → RGB_565，其他 → ARGB_8888
     */
    private String saveScaledIcon(Uri uri) {
        if (uri == null) return null;

        InputStream is = null;
        FileOutputStream fos = null;
        Bitmap scaled = null;
        String result = null;
        try {
            // 1. 读原图尺寸 + MIME
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            is = getContentResolver().openInputStream(uri);
            if (is == null) return null;
            BitmapFactory.decodeStream(is, null, opts);
            is.close();
            is = null;

            int srcW = opts.outWidth;
            int srcH = opts.outHeight;
            if (srcW <= 0 || srcH <= 0) return null;

            String mime = opts.outMimeType;

            // 2. 算采样率
            int sampleSize = 1;
            int maxDim = Math.max(srcW, srcH);
            while (maxDim / sampleSize > ICON_MAX_SIZE * 2) {
                sampleSize *= 2;
            }

            // 3. 解码降采样后 Bitmap
            opts = new BitmapFactory.Options();
            opts.inSampleSize = sampleSize;
            // ★ JPG 用 RGB_565 省内存；PNG/GIF 保留 ARGB_8888 支持透明
            opts.inPreferredConfig = "image/jpeg".equalsIgnoreCase(mime)
                    ? Bitmap.Config.RGB_565
                    : Bitmap.Config.ARGB_8888;
            is = getContentResolver().openInputStream(uri);
            if (is == null) return null;
            Bitmap decoded = BitmapFactory.decodeStream(is, null, opts);
            is.close();
            is = null;
            if (decoded == null) return null;

            // 4. 等比缩放到 ICON_MAX_SIZE
            int w = decoded.getWidth();
            int h = decoded.getHeight();
            float scale = Math.min(
                    (float) ICON_MAX_SIZE / w,
                    (float) ICON_MAX_SIZE / h);
            if (scale < 1f) {
                int newW = Math.max(1, (int) (w * scale));
                int newH = Math.max(1, (int) (h * scale));
                scaled = Bitmap.createScaledBitmap(decoded, newW, newH, true);
                if (scaled != decoded) decoded.recycle();
            } else {
                scaled = decoded;
            }

            // 5. 写 PNG
            File dir = new File(getFilesDir(), "custom");
            if (!dir.exists() && !dir.mkdirs()) return null;

            File outFile = new File(dir, "icon.png");
            fos = new FileOutputStream(outFile);
            scaled.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();

            result = outFile.getAbsolutePath();
            return result;

        } catch (Throwable t) {
            return null;
        } finally {
            try { if (is != null) is.close(); } catch (Throwable ignored) {}
            try { if (fos != null) fos.close(); } catch (Throwable ignored) {}
            // ★ 只在失败路径回收；成功时所有权交给调用方（或已被 GC）
            if (result == null && scaled != null && !scaled.isRecycled()) {
                scaled.recycle();
            }
        }
    }

    // ============================================================
    // 保存 / 恢复
    // ============================================================
    private void saveCustom() {
        if (inputName == null) return;

        String name = inputName.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            safeToast("应用名称不能为空", Toast.LENGTH_SHORT);
            return;
        }
        if (name.length() > NAME_MAX_LEN) {
            name = name.substring(0, NAME_MAX_LEN);
        }

        CustomManager.setName(this, name);
        safeToast("已保存，返回主页面生效", Toast.LENGTH_SHORT);
        finish();
    }

    private void confirmReset() {
        if (!canTouchUi()) return;

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("恢复默认")
                .setMessage("将清除自定义图标和应用名称，确定吗？")
                .setPositiveButton("恢复", (dlg, w) -> {
                    CustomManager.reset(CustomActivity.this);
                    safeToast("已恢复默认", Toast.LENGTH_SHORT);
                    finish();
                })
                .setNegativeButton("取消", null)
                .create();
        try { d.show(); } catch (Throwable ignored) {}
    }

    // ============================================================
    // 通用样式
    // ============================================================
    private void applyCardStyle(View view) {
        if (view == null) return;
        GradientDrawable bg = createRoundRect(COLOR_CARD, dp(20));
        bg.setStroke(dp(1), CARD_STROKE_COLOR);
        view.setBackground(bg);
        view.setElevation(dp(2));
    }

    private void setPressFeedback(final View view) {
        if (view == null) return;
        view.setOnTouchListener(new View.OnTouchListener() {
            private float downX = 0;
            private float downY = 0;
            private boolean moved = false;
            private final float THRESHOLD = 24f;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (v == null || event == null) return false;

                ViewGroup parent = (v.getParent() instanceof ViewGroup)
                        ? (ViewGroup) v.getParent() : null;

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        if (parent != null)
                            parent.requestDisallowInterceptTouchEvent(true);
                        downX = event.getX();
                        downY = event.getY();
                        moved = false;
                        v.animate().scaleX(0.98f).scaleY(0.98f).alpha(0.9f)
                                .setDuration(80).start();
                        vibrate();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(event.getX() - downX) > THRESHOLD
                                || Math.abs(event.getY() - downY) > THRESHOLD) {
                            if (!moved) {
                                moved = true;
                                if (parent != null)
                                    parent.requestDisallowInterceptTouchEvent(false);
                                v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                                        .setDuration(100).start();
                            }
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (parent != null)
                            parent.requestDisallowInterceptTouchEvent(false);
                        v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                                .setDuration(200).start();
                        if (!moved) v.performClick();
                        return true;

                    case MotionEvent.ACTION_CANCEL:
                        if (parent != null)
                            parent.requestDisallowInterceptTouchEvent(false);
                        v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                                .setDuration(200).start();
                        return true;
                }
                return false;
            }
        });
    }

    private void vibrate() {
        if (!canTouchUi()) return;
        try {
            View root = findViewById(android.R.id.content);
            if (root != null) root.performHapticFeedback(
                    HapticFeedbackConstants.VIRTUAL_KEY,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
        } catch (Throwable ignored) {}
    }

    private GradientDrawable createRoundRect(String colorHex, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(Color.parseColor(colorHex));
        d.setCornerRadius(radiusPx);
        return d;
    }

    private int dp(float v) {
        return (int) (v * density + 0.5f);
    }
}